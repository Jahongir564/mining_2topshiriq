const REFRESH_INTERVAL_MS = 4000;
const MAX_LOGS = 18;
const MAX_BLOCKS_SHOWN = 6;
const METAMASK_CONNECT_TIMEOUT_MS = 15000;

function getDefaultApiBaseUrl() {
  if (window.location.protocol === "http:" || window.location.protocol === "https:") {
    return window.location.origin;
  }

  return "http://localhost:3000";
}

const state = {
  apiBaseUrl: localStorage.getItem("pow-dashboard-api-base") || getDefaultApiBaseUrl(),
  chainPayload: null,
  wallets: [],
  miners: [],
  walletLookup: null,
  demoStatus: null,
  connectedWallet: null,
  connectedChainId: null,
  hasMetaMask: false,
  knownBlockIndexes: new Set(),
  logs: [],
  refreshTimer: null,
};

const dom = {
  apiBaseUrl: document.getElementById("api-base-url"),
  saveApiUrl: document.getElementById("save-api-url"),
  apiStatusDot: document.getElementById("api-status-dot"),
  apiStatusText: document.getElementById("api-status-text"),
  connectWalletButton: document.getElementById("connect-wallet-button"),
  walletConnectStatus: document.getElementById("wallet-connect-status"),
  walletChainId: document.getElementById("wallet-chain-id"),
  walletConnectedAddress: document.getElementById("wallet-connected-address"),
  chainHeight: document.getElementById("chain-height"),
  pendingCount: document.getElementById("pending-count"),
  difficultyValue: document.getElementById("difficulty-value"),
  walletCount: document.getElementById("wallet-count"),
  refreshLabel: document.getElementById("refresh-label"),
  blockChart: document.getElementById("block-chart"),
  blocksList: document.getElementById("blocks-list"),
  mineButtons: [document.getElementById("mine-button"), document.getElementById("mine-button-alt")],
  demoStartButton: document.getElementById("demo-start-button"),
  demoStopButton: document.getElementById("demo-stop-button"),
  miningStatuses: [document.getElementById("mining-status"), document.getElementById("mining-status-alt")],
  demoStatusBadge: document.getElementById("demo-status-badge"),
  lastRefreshTime: document.getElementById("last-refresh-time"),
  latestMinedBlock: document.getElementById("latest-mined-block"),
  clearLogs: document.getElementById("clear-logs"),
  logList: document.getElementById("log-list"),
  walletsList: document.getElementById("wallets-list"),
  walletLookupInput: document.getElementById("wallet-lookup-input"),
  walletLookupButton: document.getElementById("wallet-lookup-button"),
  walletLookupResult: document.getElementById("wallet-lookup-result"),
  transactionForm: document.getElementById("transaction-form"),
  transactionMessage: document.getElementById("transaction-message"),
  swapForm: document.getElementById("swap-form"),
  swapWalletSelect: document.getElementById("swap-wallet-select"),
  swapMessage: document.getElementById("swap-message"),
  minersList: document.getElementById("miners-list"),
  toastStack: document.getElementById("toast-stack"),
  navLinks: document.querySelectorAll(".nav-link"),
  views: document.querySelectorAll(".view"),
  currentViewTitle: document.getElementById("current-view-title"),
};

dom.apiBaseUrl.value = state.apiBaseUrl;

function getEthereumProvider() {
  if (window.ethereum) {
    return window.ethereum;
  }

  return null;
}

function isFileProtocol() {
  return window.location.protocol === "file:";
}

function truncateAddress(address) {
  if (!address) {
    return "Not connected";
  }

  return `${address.slice(0, 10)}...${address.slice(-8)}`;
}

function renderWalletConnection() {
  if (!state.hasMetaMask) {
    const isLocalFile = isFileProtocol();
    dom.walletConnectStatus.textContent = isLocalFile
      ? "MetaMask inject qilinmagan"
      : "MetaMask not found";
    dom.walletChainId.textContent = "--";
    dom.walletConnectedAddress.textContent = isLocalFile
      ? "Bu sahifa file:// orqali ochilgan. MetaMask ishlashi uchun extension settings ichida file URL access ni yoqing yoki sahifani local server orqali oching."
      : "Install MetaMask to connect a wallet.";
    dom.connectWalletButton.textContent = isLocalFile
      ? "Enable MetaMask Access"
      : "Install MetaMask";
    dom.connectWalletButton.disabled = false;
    return;
  }

  dom.connectWalletButton.disabled = false;

  if (state.connectedWallet) {
    dom.walletConnectStatus.textContent = "Connected";
    dom.walletChainId.textContent = state.connectedChainId || "--";
    dom.walletConnectedAddress.textContent = state.connectedWallet;
    dom.connectWalletButton.textContent = "Connect Wallet";
  } else {
    dom.walletConnectStatus.textContent = "Ready to connect";
    dom.walletChainId.textContent = state.connectedChainId || "--";
    dom.walletConnectedAddress.textContent = "Connect Wallet tugmasini bosing.";
    dom.connectWalletButton.textContent = "Connect Wallet";
  }
}

function setApiStatus(mode, text) {
  dom.apiStatusDot.classList.remove("online", "offline");

  if (mode === "online") {
    dom.apiStatusDot.classList.add("online");
  } else if (mode === "offline") {
    dom.apiStatusDot.classList.add("offline");
  }

  dom.apiStatusText.textContent = text;
}

function setMessage(element, text, type = "muted") {
  element.textContent = text;
  element.classList.remove("success", "error");
  
  if (type === "success" || type === "error") {
    element.classList.add(type);
    element.style.display = "block";
  } else if (!text) {
    element.style.display = "none";
  } else {
    element.style.display = "block";
  }
}

function showToast(message, type = "success") {
  const toast = document.createElement("div");
  toast.className = `toast ${type}`;
  toast.textContent = message;
  dom.toastStack.appendChild(toast);

  setTimeout(() => {
    toast.remove();
  }, 3200);
}

function addLog(message, type = "info") {
  const entry = {
    id: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
    time: new Date().toLocaleTimeString(),
    message,
    type,
  };

  state.logs.unshift(entry);
  state.logs = state.logs.slice(0, MAX_LOGS);
  renderLogs();
}

function renderLogs() {
  if (!state.logs.length) {
    dom.logList.innerHTML = '<p class="empty-copy">No logs yet. Trigger mining or submit a transaction.</p>';
    return;
  }

  dom.logList.innerHTML = state.logs
    .map(
      (entry) => `
        <article class="log-item">
          <span class="log-time">${entry.time}</span>
          <div>${entry.message}</div>
        </article>
      `
    )
    .join("");
}

async function apiFetch(path, options = {}) {
  const url = `${state.apiBaseUrl}${path}`;
  console.log("[api]", options.method || "GET", url, options.body || "");

  const response = await fetch(url, {
    headers: {
      "Content-Type": "application/json",
      ...(options.headers || {}),
    },
    ...options,
  });

  let payload = null;

  try {
    payload = await response.json();
  } catch (error) {
    payload = null;
  }

  console.log("[api:response]", response.status, path, payload);

  if (!response.ok) {
    const errorMessage = payload?.error || payload?.message || `Request failed with status ${response.status}.`;
    throw new Error(errorMessage);
  }

  return payload;
}

function updateOverview() {
  const chain = state.chainPayload?.chain || [];
  const pendingTransactions = state.chainPayload?.pendingTransactions || [];
  dom.chainHeight.textContent = chain.length;
  dom.pendingCount.textContent = pendingTransactions.length;
  dom.difficultyValue.textContent = `0000 (${state.chainPayload?.difficulty ?? "--"})`;
  dom.walletCount.textContent = state.wallets.length;
  dom.refreshLabel.textContent = `Auto-refresh every ${REFRESH_INTERVAL_MS / 1000} seconds`;
  dom.lastRefreshTime.textContent = `Last sync ${new Date().toLocaleTimeString()}`;
}

function renderDemoStatus() {
  const isRunning = Boolean(
    state.demoStatus?.isRunning ?? state.chainPayload?.demo?.isRunning
  );

  dom.demoStatusBadge.textContent = isRunning ? "Demo: Running" : "Demo: Stopped";
  dom.demoStatusBadge.classList.remove("success", "error");
  dom.demoStatusBadge.classList.add(isRunning ? "success" : "error");
  dom.demoStartButton.disabled = isRunning;
  dom.demoStopButton.disabled = !isRunning;
}

function renderBlockChart(blocks) {
  const recentBlocks = blocks.slice(-MAX_BLOCKS_SHOWN);

  if (!recentBlocks.length) {
    dom.blockChart.innerHTML = '<p class="empty-copy">No block activity yet.</p>';
    return;
  }

  const maxTransactions = Math.max(...recentBlocks.map((block) => block.transactions.length), 1);

  dom.blockChart.innerHTML = recentBlocks
    .map((block) => {
      const height = Math.max((block.transactions.length / maxTransactions) * 120, 16);

      return `
        <div class="bar-wrap">
          <span class="bar-value">${block.transactions.length} tx</span>
          <div class="bar" style="height: ${height}px"></div>
          <span class="bar-label">#${block.index}</span>
        </div>
      `;
    })
    .join("");
}

function truncateHash(hash) {
  if (!hash) {
    return "--";
  }

  return `${hash.slice(0, 16)}...${hash.slice(-12)}`;
}

function renderBlocks() {
  const blocks = (state.chainPayload?.chain || []).slice().reverse().slice(0, MAX_BLOCKS_SHOWN);

  if (!blocks.length) {
    dom.blocksList.innerHTML = '<p class="empty-copy">No blocks available.</p>';
    return;
  }

  dom.blocksList.innerHTML = blocks
    .map((block) => {
      const isNew = !state.knownBlockIndexes.has(block.index);

      return `
        <article class="block-card ${isNew ? "new-block" : ""}">
          <div class="block-head">
            <strong>Block #${block.index}</strong>
            <span class="chip">${block.transactions.length} transactions</span>
          </div>
          <p class="muted-text">${new Date(block.timestamp).toLocaleString()}</p>
          <div class="hash-grid">
            <div class="hash-box">
              <p>Hash</p>
              <div class="hash">${truncateHash(block.hash)}</div>
            </div>
            <div class="hash-box">
              <p>Previous Hash</p>
              <div class="hash">${truncateHash(block.previousHash)}</div>
            </div>
          </div>
        </article>
      `;
    })
    .join("");
}

function renderLatestMinedBlock() {
  const summary = state.chainPayload?.lastMiningSummary;

  if (!summary) {
    dom.latestMinedBlock.innerHTML = '<p class="empty-copy">No mined block data yet.</p>';
    return;
  }

  const rewardRows = summary.rewardBreakdown
    .map(
      (reward) => `
        <li class="reward-item">
          <strong>${reward.receiver}</strong> earned ${formatNumber(reward.amount)} ${reward.token}
        </li>
      `
    )
    .join("");

  dom.latestMinedBlock.innerHTML = `
    <div class="block-head">
      <strong>Latest Block #${summary.blockIndex}</strong>
      <span class="chip">${summary.reason} mining</span>
    </div>
    <div class="summary-grid">
      <div class="summary-box">
        <p>Nonce</p>
        <span>${summary.nonce}</span>
      </div>
      <div class="summary-box">
        <p>Attempts</p>
        <span>${summary.attempts}</span>
      </div>
      <div class="summary-box">
        <p>Difficulty</p>
        <span>${summary.difficulty}</span>
      </div>
      <div class="summary-box">
        <p>Transactions</p>
        <span>${summary.includedTransactions.length}</span>
      </div>
    </div>
    <div class="hash-box" style="margin-top: 14px;">
      <p>Block Hash</p>
      <div class="hash">${summary.hash}</div>
    </div>
    <ul class="reward-list">${rewardRows}</ul>
  `;
}

function renderWallets() {
  if (!state.wallets.length) {
    dom.walletsList.innerHTML = '<p class="empty-copy">No wallets available.</p>';
    return;
  }

  dom.walletsList.innerHTML = state.wallets
    .map(
      (wallet) => `
        <article class="wallet-card">
          <div class="wallet-head">
            <strong>${wallet.address}</strong>
            <span class="chip">Balance ${formatNumber(wallet.balance)}</span>
          </div>
          <div class="wallet-balance-row">
            <div class="balance-box">
              <p>TokenA</p>
              <span>${formatNumber(wallet.balances.TokenA)}</span>
            </div>
            <div class="balance-box">
              <p>TokenB</p>
              <span>${formatNumber(wallet.balances.TokenB)}</span>
            </div>
          </div>
        </article>
      `
    )
    .join("");

  const currentValue = dom.swapWalletSelect.value;
  dom.swapWalletSelect.innerHTML = state.wallets
    .map((wallet) => `<option value="${wallet.address}">${wallet.address}</option>`)
    .join("");

  if (currentValue && state.wallets.some((wallet) => wallet.address === currentValue)) {
    dom.swapWalletSelect.value = currentValue;
  }
}

function renderWalletLookup() {
  if (!state.walletLookup) {
    dom.walletLookupResult.innerHTML =
      '<p class="empty-copy">Look up a specific wallet to inspect its balances.</p>';
    return;
  }

  dom.walletLookupResult.innerHTML = `
    <div class="wallet-head">
      <strong>${state.walletLookup.address}</strong>
      <span class="chip">Lookup Result</span>
    </div>
    <div class="wallet-balance-row">
      <div class="balance-box">
        <p>TokenA</p>
        <span>${formatNumber(state.walletLookup.balances.TokenA)}</span>
      </div>
      <div class="balance-box">
        <p>TokenB</p>
        <span>${formatNumber(state.walletLookup.balances.TokenB)}</span>
      </div>
    </div>
  `;
}

function renderMiners() {
  if (!state.miners.length) {
    dom.minersList.innerHTML = '<p class="empty-copy">No miners available.</p>';
    return;
  }

  const maxContribution = Math.max(...state.miners.map((miner) => miner.totalContribution), 1);

  dom.minersList.innerHTML = state.miners
    .map((miner) => {
      const contributionWidth = Math.max((miner.totalContribution / maxContribution) * 100, 8);

      return `
        <article class="miner-card">
          <div class="miner-head">
            <strong>${miner.name}</strong>
            <span class="chip">Power ${miner.hashPower}</span>
          </div>
          <p class="muted-text-mini mono" style="word-break: break-all; margin-top: 4px;">${miner.address}</p>
          <div class="miner-stats">
            <div class="miner-stat">
              <p>Contribution</p>
              <span>${formatNumber(miner.totalContribution)}</span>
            </div>
            <div class="miner-stat">
              <p>Earned</p>
              <span>${formatNumber(miner.totalEarned)} TokenA</span>
            </div>
          </div>
          <div class="contribution-section">
            <p class="field-label" style="font-size: 10px; margin-bottom: 4px;">Network Share</p>
            <div class="contribution-bar-bg">
              <div class="contribution-bar-fill" style="width: ${contributionWidth}%;"></div>
            </div>
          </div>
        </article>
      `;
    })
    .join("");
}

function formatNumber(value) {
  return Number(value ?? 0).toLocaleString(undefined, {
    maximumFractionDigits: 4,
  });
}

function syncConnectedWalletIntoForms() {
  if (!state.connectedWallet) {
    return;
  }

  const senderInput = dom.transactionForm.elements.sender;

  if (!senderInput.value.trim()) {
    senderInput.value = state.connectedWallet;
  }

  if (!dom.walletLookupInput.value.trim()) {
    dom.walletLookupInput.value = state.connectedWallet;
  }
}

async function connectMetaMask() {
  const provider = getEthereumProvider();
  console.log("[metamask] connect request");

  if (!provider) {
    state.hasMetaMask = false;
    renderWalletConnection();

    if (isFileProtocol()) {
      const helpMessage =
        "Sahifa file:// orqali ochilgan. MetaMask extension settings ichida 'Allow access to file URLs' ni yoqing yoki frontendni local server orqali oching.";
      showToast(helpMessage, "error");
      addLog(helpMessage, "error");
    } else {
      showToast("MetaMask topilmadi.", "error");
      addLog("MetaMask not detected in browser.", "error");
      window.open("https://metamask.io/download/", "_blank", "noopener,noreferrer");
    }

    return;
  }

  state.hasMetaMask = true;
  dom.connectWalletButton.disabled = true;
  dom.connectWalletButton.textContent = "Connecting...";

  try {
    await provider.request({
      method: "wallet_requestPermissions",
      params: [{ eth_accounts: {} }],
    });

    const accounts = await Promise.race([
      provider.request({ method: "eth_requestAccounts" }),
      new Promise((_, reject) => {
        setTimeout(() => {
          reject(new Error("MetaMask connection timed out. Open the app from http://localhost:3000 and try again."));
        }, METAMASK_CONNECT_TIMEOUT_MS);
      }),
    ]);
    const chainId = await provider.request({ method: "eth_chainId" });

    state.hasMetaMask = true;
    state.connectedWallet = accounts[0] || null;
    state.connectedChainId = chainId || null;

    console.log("[metamask] connected", {
      address: state.connectedWallet,
      chainId: state.connectedChainId,
    });

    renderWalletConnection();
    syncConnectedWalletIntoForms();
    addLog(`MetaMask connected: ${truncateAddress(state.connectedWallet)}.`, "success");
    showToast("MetaMask connected successfully.", "success");
  } catch (error) {
    console.error("[metamask] connection failed", error);
    renderWalletConnection();
    addLog(`MetaMask connection failed: ${error.message}`, "error");
    showToast(error.message || "MetaMask ulanishi bekor qilindi.", "error");
  } finally {
    if (state.hasMetaMask) {
      dom.connectWalletButton.disabled = false;
    }
  }
}

async function hydrateWalletConnection() {
  const provider = getEthereumProvider();
  state.hasMetaMask = Boolean(provider);

  if (!provider) {
    renderWalletConnection();

    if (isFileProtocol()) {
      addLog(
        "MetaMask file:// sahifaga inject qilinmadi. 'Allow access to file URLs' ni yoqing yoki local server ishlating.",
        "error"
      );
    }

    return;
  }

  try {
    const chainId = await provider.request({ method: "eth_chainId" });
    state.connectedWallet = null;
    state.connectedChainId = chainId || null;

    console.log("[metamask] initial state", {
      address: null,
      chainId: state.connectedChainId,
    });
  } catch (error) {
    console.error("[metamask] initial state failed", error);
    addLog(`MetaMask state check failed: ${error.message}`, "error");
  }

  renderWalletConnection();
  syncConnectedWalletIntoForms();
}

function setupWalletEvents() {
  const provider = getEthereumProvider();

  if (!provider || typeof provider.on !== "function") {
    return;
  }

  provider.on("accountsChanged", (accounts) => {
    state.connectedWallet = accounts[0] || null;
    console.log("[metamask] accountsChanged", accounts);
    renderWalletConnection();
    syncConnectedWalletIntoForms();

    if (state.connectedWallet) {
      addLog(`MetaMask account changed: ${truncateAddress(state.connectedWallet)}.`);
    } else {
      addLog("MetaMask account disconnected.", "error");
    }
  });

  provider.on("chainChanged", (chainId) => {
    state.connectedChainId = chainId;
    console.log("[metamask] chainChanged", chainId);
    renderWalletConnection();
    addLog(`MetaMask chain changed to ${chainId}.`);
  });
}

async function refreshDashboard({ silent = false } = {}) {
  try {
    if (!silent) {
      setApiStatus("pending", "Refreshing chain data...");
    }

    const [chainPayload, wallets, miners, demoStatus] = await Promise.all([
      apiFetch("/chain"),
      apiFetch("/wallets"),
      apiFetch("/miners"),
      apiFetch("/demo/status"),
    ]);

    const previousBlockCount = state.chainPayload?.chain?.length || 0;
    const latestBlock = chainPayload.chain[chainPayload.chain.length - 1];
    const isNewBlock = chainPayload.chain.length > previousBlockCount;

    state.chainPayload = chainPayload;
    state.wallets = wallets;
    state.miners = miners;
    state.demoStatus = demoStatus;

    updateOverview();
    renderDemoStatus();
    renderBlockChart(chainPayload.chain);
    renderBlocks();
    renderLatestMinedBlock();
    renderWallets();
    renderWalletLookup();
    renderMiners();

    if (isNewBlock && latestBlock) {
      addLog(`New block #${latestBlock.index} detected on the chain.`, "success");
      showToast(`Block #${latestBlock.index} mined successfully.`, "success");
    }

    state.knownBlockIndexes = new Set(chainPayload.chain.map((block) => block.index));
    setApiStatus("online", `Backend online at ${state.apiBaseUrl}`);

    if (window.refreshIcons) {
      window.refreshIcons();
    }
  } catch (error) {
    console.error(error);
    setApiStatus("offline", error.message);
    addLog(`Backend request failed: ${error.message}`, "error");

    if (!silent) {
      showToast(error.message, "error");
    }
  }
}

async function updateDemoActivity(shouldStart) {
  const targetButton = shouldStart ? dom.demoStartButton : dom.demoStopButton;
  const actionLabel = shouldStart ? "starting" : "stopping";
  const endpoint = shouldStart ? "/demo/start" : "/demo/stop";

  dom.demoStartButton.disabled = true;
  dom.demoStopButton.disabled = true;
  addLog(`Demo auto activity ${actionLabel} request sent.`);

  try {
    const result = await apiFetch(endpoint, {
      method: "POST",
      body: JSON.stringify({}),
    });

    state.demoStatus = result.demo;
    renderDemoStatus();
    addLog(result.message, "success");
    showToast(result.message, "success");
    await refreshDashboard({ silent: true });
  } catch (error) {
    renderDemoStatus();
    addLog(`Demo activity update failed: ${error.message}`, "error");
    showToast(error.message, "error");
  }
}

async function lookupWallet() {
  const address = dom.walletLookupInput.value.trim();

  if (!address) {
    showToast("Enter a wallet address first.", "error");
    return;
  }

  dom.walletLookupButton.disabled = true;

  try {
    const wallet = await apiFetch(`/wallet/${encodeURIComponent(address)}`);
    state.walletLookup = wallet;
    renderWalletLookup();
    addLog(`Loaded wallet ${wallet.address}.`);
  } catch (error) {
    showToast(error.message, "error");
    addLog(`Wallet lookup failed for ${address}: ${error.message}`, "error");
  } finally {
    dom.walletLookupButton.disabled = false;
  }
}

async function submitTransaction(event) {
  event.preventDefault();
  const formData = new FormData(dom.transactionForm);
  const payload = {
    sender: formData.get("sender").trim(),
    receiver: formData.get("receiver").trim(),
    amount: Number(formData.get("amount")),
    token: formData.get("token"),
    type: "web-transfer",
  };

  const submitButton = dom.transactionForm.querySelector("button[type='submit']");
  submitButton.disabled = true;
  setMessage(dom.transactionMessage, "Submitting transaction...");

  try {
    const result = await apiFetch("/transaction", {
      method: "POST",
      body: JSON.stringify(payload),
    });

    setMessage(dom.transactionMessage, result.message || "Transaction submitted.", "success");
    showToast("Transaction submitted.", "success");
    addLog(`Transaction queued: ${payload.sender} -> ${payload.receiver} (${payload.amount} ${payload.token}).`, "success");
    dom.transactionForm.reset();
    await refreshDashboard({ silent: true });
  } catch (error) {
    setMessage(dom.transactionMessage, error.message, "error");
    showToast(error.message, "error");
    addLog(`Transaction failed: ${error.message}`, "error");
  } finally {
    submitButton.disabled = false;
  }
}

async function triggerMining() {
  dom.mineButtons.forEach(btn => btn && (btn.disabled = true));
  dom.miningStatuses.forEach(st => st && (st.textContent = "Mining..."));
  addLog("Manual mining request sent to backend.");

  try {
    const result = await apiFetch("/mine");
    const message = result.message || "Mining request finished.";
    dom.miningStatuses.forEach(st => st && (st.textContent = "Complete"));
    addLog(message, "success");
    showToast(message, "success");
    await refreshDashboard({ silent: true });
  } catch (error) {
    dom.miningStatuses.forEach(st => st && (st.textContent = "Error"));
    addLog(`Mining failed: ${error.message}`, "error");
    showToast(error.message, "error");
  } finally {
    dom.mineButtons.forEach(btn => btn && (btn.disabled = false));
  }
}

async function submitSwap(event) {
  event.preventDefault();
  const formData = new FormData(dom.swapForm);
  const payload = {
    address: formData.get("address"),
    amount: Number(formData.get("amount")),
    fromToken: "TokenA",
    toToken: "TokenB",
  };

  const submitButton = dom.swapForm.querySelector("button[type='submit']");
  submitButton.disabled = true;
  setMessage(dom.swapMessage, "Executing swap...");

  try {
    const result = await apiFetch("/swap", {
      method: "POST",
      body: JSON.stringify(payload),
    });

    setMessage(dom.swapMessage, result.message || "Swap completed.", "success");
    showToast("Swap request sent.", "success");
    addLog(`Swap submitted for ${payload.address}: ${payload.amount} TokenA -> TokenB.`, "success");
    dom.swapForm.reset();
    await refreshDashboard({ silent: true });
  } catch (error) {
    setMessage(dom.swapMessage, error.message, "error");
    showToast(error.message, "error");
    addLog(`Swap failed: ${error.message}`, "error");
  } finally {
    submitButton.disabled = false;
  }
}

function saveApiBaseUrl() {
  const value = dom.apiBaseUrl.value.trim().replace(/\/$/, "");

  if (!value) {
    showToast("API base URL cannot be empty.", "error");
    return;
  }

  state.apiBaseUrl = value;
  localStorage.setItem("pow-dashboard-api-base", value);
  addLog(`API base URL updated to ${value}.`);
  refreshDashboard();
}

function startAutoRefresh() {
  if (state.refreshTimer) {
    clearInterval(state.refreshTimer);
  }

  state.refreshTimer = setInterval(() => {
    refreshDashboard({ silent: true });
  }, REFRESH_INTERVAL_MS);
}

function switchView(viewId) {
  dom.views.forEach(view => view.classList.remove("active"));
  dom.navLinks.forEach(link => link.classList.remove("active"));

  const targetView = document.getElementById(`view-${viewId}`);
  const targetLink = document.querySelector(`.nav-link[data-view="${viewId}"]`);

  if (targetView && targetLink) {
    targetView.classList.add("active");
    targetLink.classList.add("active");
    dom.currentViewTitle.textContent = targetLink.querySelector("span").textContent;
  }
}

function bindEvents() {
  dom.saveApiUrl.addEventListener("click", saveApiBaseUrl);
  dom.connectWalletButton.addEventListener("click", connectMetaMask);
  dom.walletLookupButton.addEventListener("click", lookupWallet);
  dom.transactionForm.addEventListener("submit", submitTransaction);
  dom.swapForm.addEventListener("submit", submitSwap);
  
  dom.mineButtons.forEach(btn => {
    if (btn) btn.addEventListener("click", triggerMining);
  });

  dom.demoStartButton.addEventListener("click", () => updateDemoActivity(true));
  dom.demoStopButton.addEventListener("click", () => updateDemoActivity(false));
  
  dom.navLinks.forEach(link => {
    link.addEventListener("click", () => switchView(link.dataset.view));
  });

  dom.clearLogs.addEventListener("click", () => {
    state.logs = [];
    renderLogs();
  });
  
  dom.walletLookupInput.addEventListener("keydown", (event) => {
    if (event.key === "Enter") {
      event.preventDefault();
      lookupWallet();
    }
  });
}

function init() {
  bindEvents();
  renderLogs();
  renderWalletConnection();
  renderDemoStatus();
  hydrateWalletConnection();
  setupWalletEvents();
  refreshDashboard();
  startAutoRefresh();
}

init();
